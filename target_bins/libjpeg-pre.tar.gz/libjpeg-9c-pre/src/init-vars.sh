#!/bin/sh
echo "This must run from inside lava32 docker container"

# Build preprocessed files
make
make clean

# Compile with preprocessed files
../../../tools/btrace/sw-btrace make
# Generate compile_commands.json
../../../tools/btrace/sw-btrace-to-compiledb

# Generate initializing replacements
../../../tools/install/bin/lavaInitTool *-pre.c

# Apply patches
/llvm-3.6.2/Release/bin/^Cang-apply-replacements .

# TODO: manually patch out the bad ones

