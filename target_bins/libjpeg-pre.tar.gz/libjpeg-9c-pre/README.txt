libjpeg version 9c from https://www.ijg.org/files/jpegsrc.v9c.tar.gz
Preprocessed built with custom Makefile
Preprocessed files initialized with lavaInitTool
    Two manual fixes were required to fix synax errors introduced by lavaInitTool:
    jdarith-pre.c:3737 and jdhuff-pre.c:4248
